<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = array(
  0x00 => 'guo', 'yin', 'hun', 'pu', 'yu', 'han', 'yuan', 'lun', 'quan', 'yu', 'qing', 'guo', 'chuan', 'wei', 'yuan', 'quan',
  0x10 => 'ku', 'fu', 'yuan', 'yuan', 'ya', 'tu', 'tu', 'tu', 'tuan', 'lue', 'hui', 'yi', 'huan', 'luan', 'luan', 'tu',
  0x20 => 'ya', 'tu', 'ting', 'sheng', 'pu', 'lu', 'kuai', 'ya', 'zai', 'wei', 'ge', 'yu', 'wu', 'gui', 'pi', 'yi',
  0x30 => 'de', 'qian', 'qian', 'zhen', 'zhuo', 'dang', 'qia', 'xia', 'shan', 'kuang', 'chang', 'qi', 'nie', 'mo', 'ji', 'jia',
  0x40 => 'zhi', 'zhi', 'ban', 'xun', 'yi', 'qin', 'mei', 'jun', 'rong', 'tun', 'fang', 'ben', 'ben', 'tan', 'kan', 'huai',
  0x50 => 'zuo', 'keng', 'bi', 'jing', 'di', 'jing', 'ji', 'kuai', 'di', 'jing', 'jian', 'tan', 'li', 'ba', 'wu', 'fen',
  0x60 => 'zhui', 'po', 'ban', 'tang', 'kun', 'qu', 'tan', 'zhi', 'tuo', 'gan', 'ping', 'dian', 'gua', 'ni', 'tai', 'pi',
  0x70 => 'jiong', 'yang', 'fo', 'ao', 'lu', 'qiu', 'mu', 'ke', 'gou', 'xue', 'ba', 'chi', 'che', 'ling', 'zhu', 'fu',
  0x80 => 'hu', 'zhi', 'chui', 'la', 'long', 'long', 'lu', 'ao', 'dai', 'pao', 'min', 'xing', 'dong', 'ji', 'he', 'lu',
  0x90 => 'ci', 'chi', 'lei', 'gai', 'yin', 'hou', 'dui', 'zhao', 'fu', 'guang', 'yao', 'duo', 'duo', 'gui', 'cha', 'yang',
  0xA0 => 'yin', 'fa', 'gou', 'yuan', 'die', 'xie', 'ken', 'shang', 'shou', 'e', 'bing', 'dian', 'hong', 'ya', 'kua', 'da',
  0xB0 => 'ka', 'dang', 'kai', 'hang', 'nao', 'an', 'xing', 'xian', 'yuan', 'bang', 'fu', 'ba', 'yi', 'yin', 'han', 'xu',
  0xC0 => 'chui', 'qin', 'geng', 'ai', 'beng', 'fang', 'que', 'yong', 'jun', 'jia', 'di', 'mai', 'lang', 'juan', 'cheng', 'shan',
  0xD0 => 'jin', 'zhe', 'lie', 'lie', 'bu', 'cheng', 'hua', 'bu', 'shi', 'xun', 'guo', 'jiong', 'ye', 'nian', 'di', 'yu',
  0xE0 => 'bu', 'ya', 'quan', 'sui', 'pi', 'qing', 'wan', 'ju', 'lun', 'zheng', 'kong', 'chong', 'dong', 'dai', 'tan', 'an',
  0xF0 => 'cai', 'chu', 'beng', 'kan', 'zhi', 'duo', 'yi', 'zhi', 'yi', 'pei', 'ji', 'zhun', 'qi', 'sao', 'ju', 'ni',
);
